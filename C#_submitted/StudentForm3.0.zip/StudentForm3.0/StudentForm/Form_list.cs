﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentForm
{
    public partial class Form_list : Form
    {
        
        List<Student> stud = new List<Student>();


        public Form_list()
        {
            InitializeComponent();
        }

        private void Form_list_Load(object sender, EventArgs e)
        {

        }
        private void RefreshList(object sender, EventArgs e)
        {
           // RefreshList();

        }
        private void RefreshList()
        {
            listView1.SuspendLayout();
            listView1.Items.Clear();


            ListViewItem itemdisplay;
            foreach( Student st in stud){

                itemdisplay = listView1.Items.Add(st.stuID);
                itemdisplay.SubItems.Add(st.Fname);
                itemdisplay.SubItems.Add(st.resident.ToString());
                itemdisplay.SubItems.Add(st.credit.ToString());
                itemdisplay.SubItems.Add(st.tuition.ToString());


            }

            listView1.ResumeLayout();
        }

        private void Add_button_Click(object sender, EventArgs e)
        {
            The_Form studentform = new The_Form();
            studentform.Owner = this;
            studentform.ShowDialog();

            stud.Add(new Student { Fname = studentform.student_Name, Tuition = studentform.student_tuition, 
                StudID = studentform.student_ID, Credit = studentform.student_credits, 
                Resident = studentform.student_res });
            RefreshList();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Exit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Delete_button_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                stud.RemoveAt(listView1.SelectedIndices[0]);
                listView1.SelectedItems[0].Remove();
                //MessageBox.Show(listView1.SelectedIndices[0].ToString());
                
            }
            else
            {
                MessageBox.Show("Nothing Selected");
            }
        }

        private void Update_button_Click(object sender, EventArgs e)
        {
            The_Form students = new The_Form();
            students.Owner = this;
            if (listView1.SelectedItems.Count == 1)
            {
                students.student_Name = stud[listView1.SelectedIndices[0]].Fname;
                students.student_ID = stud[listView1.SelectedIndices[0]].StudID;
                students.student_credits = stud[listView1.SelectedIndices[0]].Credit;
                students.student_tuition = stud[listView1.SelectedIndices[0]].Tuition;
                students.student_res = stud[listView1.SelectedIndices[0]].Resident;
                students.ShowDialog();

                stud[listView1.SelectedIndices[0]].Fname = students.student_Name;
                stud[listView1.SelectedIndices[0]].StudID = students.student_ID;
                stud[listView1.SelectedIndices[0]].Credit = students.student_credits;
                stud[listView1.SelectedIndices[0]].Tuition = students.student_tuition;
                stud[listView1.SelectedIndices[0]].Resident = students.student_res;
            }
            else
            {
                MessageBox.Show("Nothing Selected");
            }
            
            
            RefreshList();

        }

        private void button1_Click(object sender, EventArgs e)
        {




        }
    }
}
