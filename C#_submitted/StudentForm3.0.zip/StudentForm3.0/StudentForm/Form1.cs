﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentForm
{
    public partial class The_Form : Form
    {
       // public Form_list Owner; 
        public string student_ID ="";
        public string student_Name= "";
        public int student_credits = 0 ;
        public double student_tuition = 0;
        public bool student_res = true;
        public The_Form()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           

        }

        public void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {
           
        }

        public void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string value = null;
            
            if (radioButton1.Checked == true)
            {
                 int value1 = (int.Parse(textBox3.Text) * 300);
                   value = value1.ToString();
            }
            if (radioButton2.Checked == true)
            {
                 int value2 = int.Parse(textBox3.Text) * 800;
                 value = value2.ToString();
                
            }

            this.Tuition_name.Text = value; 
        }

        public void ok_button_Click(object sender, EventArgs e)
        {
             student_ID = textBox1.Text;
             student_Name = textBox2.Text;
             student_credits = int.Parse(textBox3.Text);
             student_tuition = double.Parse(Tuition_name.Text);
             if (radioButton1.Checked == true)
             {
                 student_res = true;
             }
             else
             {
                 student_res = false;
             }
            this.Close();
        }

        private void The_Form_Load(object sender, EventArgs e)
        {
            textBox1.Text = student_ID;
            textBox2.Text = student_Name;
            textBox3.Text = student_credits.ToString();
            Tuition_name.Text = student_tuition.ToString();
            if (student_res == true)
            {
                radioButton1.Checked = true;
            }
            else
            {
                radioButton2.Checked = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
